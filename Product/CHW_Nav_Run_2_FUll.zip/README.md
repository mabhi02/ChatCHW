# CHW Navigator: WHO CHW guide 2012

Open this README first. It is the navigation file for everything in the zip.

| Field | Value |
|-------|-------|
| Run ID | `run_8970cf65` |
| Source manual | WHO CHW guide 2012 |
| Model | Claude Opus 4.6 (temperature 0, all three stages) |
| Git SHA | `9000e86` |
| Started | 2026-04-15 22:05:18 UTC |
| Wall clock | 1390.8s |
| Chunks | 21 |
| Total labels (raw) | 1,675 |
| Deduped labels into REPL | 1,054 |
| Total cost (Anthropic) | $14.18 |

## Quick start (where to look first)

If you want to **see the decision logic the model produced**, open `clinical_logic.json` and `flowchart.png`. The JSON is the source of truth; the PNG is a one-page overview.

If you want to **deploy the form**, take `form.xlsx` (XLSForm) and `clinical_logic.dmn` (DMN 1.3 XML). They are derived from the JSON via deterministic Python converters.

If you want to **review what the LLM saw and said**, open `system_prompt.md` (the full prompt bundle, all three stages) and `stage3_repl.json` (the actual Stage 3 input and final output).

If you want to **trace a rule back to the manual**, every entry in `clinical_logic.json` carries a `source_section_id` and `source_quote`. The full reconstructed manual text is in `reconstructed_guide.txt`.

If you want **per-variable scope and lifecycle** (which module collects what, what depends on what), open `artifacts/data_flow.json`.

If a separate `FAILURES.md` is in this zip, it contains the post-run audit (auto-registered ids, orphan variables, underproduced chunks, known issues from this specific run). Read it after the README, before drawing conclusions.

## How this bundle was produced

Three Opus calls per chunk-or-session, all temperature 0, against the same content-hashed PDF.

1. **Chunk** (deterministic Python). The cached PDF JSON is split into ~2K-token micro-chunks. No LLM.
2. **Stage 1A: Label** (Opus, one call per chunk, parallel). Each chunk gets every clinical item annotated with id + type + span + quote_context.
3. **Stage 1B: QC** (Opus, one call per chunk). Drops hallucinated labels; never adds new ones.
4. **Dedupe** (deterministic Python). Exact-string dedup on `(id, type)`.
5. **Stage 3: REPL compile** (Opus, one Python REPL session). Reads the deduped inventory + the full reconstructed guide as cached blocks; emits the seven artifacts in DAG order: supply_list -> variables -> predicates -> modules -> router -> integrative -> phrase_bank.
6. **Reconcile** (deterministic Python). Cross-references every id; auto-registers anything Phase B referenced but Phase A missed (`_auto_registered: true`).
7. **Derive** (deterministic Python). Builds `data_flow.json` and the converters (DMN XML, XLSForm, Mermaid, CSV).

The full prompts for Stage 1A, Stage 1B, and Stage 3 are in `system_prompt.md`. The naming codebook (which prefixes mean what) is its own section in that file.

## File map

### Outputs you would deploy or show a clinician

| File | What it is | Size |
|------|------------|------|
| `clinical_logic.json` | The decision model in review-friendly JSON. Source of truth. | 242.9 KB |
| `clinical_logic.dmn` | Same model, DMN 1.3 XML. Deployable to any DMN engine. | 178.3 KB |
| `form.xlsx` | CHT-deployable XLSForm. Derived from clinical_logic.json. | 11.1 KB |
| `flowchart.png` | One-page Mermaid render: router -> modules -> integrative. | 95.5 KB |
| `flowchart.md` | Mermaid source for `flowchart.png`. Re-render with mmdc or paste into mermaid.live. | 47.5 KB |
| `predicates.csv` | Flat CSV of every predicate. Easier to scan than the JSON. | 6.2 KB |
| `phrases.csv` | Flat CSV of every phrase the CHW says. | 11.4 KB |

### Per-phase emitted artifacts (the seven checkpoints)

Each of these is the Stage 3 REPL's output for one DAG step. Read in this order to follow the model's reasoning.

| File | What it is | Size |
|------|------------|------|
| `artifacts/supply_list.json` | Equipment + consumables the CHW must have on hand. | 3.6 KB |
| `artifacts/variables.json` | Every runtime input: symptoms, exam findings, measurements, demographics. | 84.5 KB |
| `artifacts/predicates.json` | Boolean predicates computed from variables (e.g. `p_fast_breathing`). | 17.4 KB |
| `artifacts/modules.json` | One decision table per clinical module (assess, diarrhoea, fever, etc.). | 97.8 KB |
| `artifacts/router.json` | The traffic cop: priority routing across modules. Row 0 is the priority-exit short-circuit. | 2.4 KB |
| `artifacts/integrative.json` | Cross-module merge rules. Often minimal because the router handles cross-module flow via flags. | 19 B |
| `artifacts/phrase_bank.json` | Every phrase the CHW says: questions, diagnoses, treatments, referrals, advice. | 24.9 KB |

Two more derived artifacts in the same directory:

| File | What it is | Size |
|------|------------|------|
| `artifacts/data_flow.json` | Per-variable scope (universal / module-scoped / cross_module / derived / orphan), source (ask/observe/measure/history), and which modules collect vs use it. | 186.9 KB |
| `artifacts/referential_integrity.json` | Cross-reference audit: every id used in modules/router/predicates must be declared. Any gap is auto-registered with `_auto_registered: true`. Reads before-state, what was added, after-state. | 193.5 KB |

### Logging and traceability

| File | What it is | Size |
|------|------------|------|
| `system_prompt.md` | Full multi-stage system prompt: Stage 1A labeling, Stage 1B QC, Stage 3 REPL compile, plus the naming codebook. This is what Opus actually saw. | 20.0 KB |
| `stage3_repl.json` | The Stage 3 REPL session: full system prompt + cached source guide + cached deduped labels + initial user message + final response + iteration count. | 912.8 KB |
| `labeled_chunks.json` | Stage 1 per-chunk output: labels per chunk + `_labeling_meta` with stage1a/stage1b token counts, response chars, and the `diff_chars` red-flag signal. | 602.8 KB |
| `deduped_labels.json` | Consolidated label set after exact-string dedup. The inventory the REPL compiled from. | 561.3 KB |
| `reconstructed_guide.txt` | The full text Opus saw at labeling time. Built from the chunker's input, not from Opus's echo. Use this to verify any label's provenance. | 187.4 KB |
| `scratchpad.md` | Step-by-step pipeline execution journal. | 1.8 KB |
| `test_suite.json` | Generated boundary + scenario test cases from the label inventory. | 737.5 KB |
| `final_dmn.validator.json` | Catcher report on the final DMN. `passed: true` plus boundary-condition warnings. | 46.2 KB |

### Internal (not reviewer-facing)

| File | What it is | Size |
|------|------------|------|
| `chunk_difficulty.json` | Per-chunk complexity score the labeling scheduler used. No clinical content. | 4.4 KB |

## How the files fit together

```
    PDF -> guide JSON (cached in Neon)
                 |
                 v
        chunker  -> 21 micro-chunks  -> reconstructed_guide.txt
                                       (full text Opus saw)
                 |
                 v
    Stage 1A label (Opus, one call per chunk, in parallel)
    Stage 1B QC   (Opus, one call per chunk)
                 |
                 v
        labeled_chunks.json  ----- per-chunk metadata + labels
                 |
                 v
        deduped_labels.json  ----- exact-string dedup, no LLM
                 |
                 v
    Stage 3 REPL (Opus, one Python session)
                 |
                 v
        artifacts/{supply_list, variables, predicates,
                   modules, router, integrative, phrase_bank}.json
                 |
                 v
        referential_integrity.json + data_flow.json
        (deterministic post-process; auto-fills registry drift)
                 |
                 v
        clinical_logic.json
                 |
       +---------+---------+----------+
       v         v         v          v
  clinical_   form.xlsx flowchart  predicates.csv
  logic.dmn  (XLSForm)  .png/.md   phrases.csv
```

Every output below `clinical_logic.json` is a deterministic transform of it. If you change the JSON and re-run the converters, the DMN, XLSForm, flowchart, and CSVs change in lockstep.
