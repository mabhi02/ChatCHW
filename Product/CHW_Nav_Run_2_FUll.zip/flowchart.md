graph TD
    classDef start fill:#6b7280,stroke:#374151,color:#fff
    classDef activator fill:#8b5cf6,stroke:#6d28d9,color:#fff
    classDef router fill:#0891b2,stroke:#0e7490,color:#fff
    classDef module fill:#4488ff,stroke:#2266cc,color:#fff
    classDef decision fill:#fef3c7,stroke:#92400e,color:#000
    classDef rule fill:#e0f2fe,stroke:#0369a1,color:#000
    classDef default_rule fill:#fef9c3,stroke:#ca8a04,color:#000
    classDef emergency fill:#dc2626,stroke:#7f1d1d,color:#fff,stroke-width:3px
    classDef integrative fill:#16a34a,stroke:#14532d,color:#fff
    classDef done fill:#059669,stroke:#064e3b,color:#fff

    START(["Patient arrives"]):::start

    subgraph ACT["Router (PRIORITY)"]
        ACT_DECIDE{{"Screen complaints"}}:::activator
        ACT_DECIDE -->|"is_priority_exit == true"| ACT_FLAG_PRIORITY_EXIT["Required: PRIORITY_EXIT"]:::rule
        ACT_DECIDE -->|"mod_danger_signs_done == false"| ACT_FLAG_mod_danger_signs["Required: mod_danger_signs"]:::rule
        ACT_DECIDE -->|"mod_prereferral_treatment_done == false"| ACT_FLAG_mod_prereferral_treatment["Required: mod_prereferral_treatment"]:::rule
        ACT_DECIDE -->|"mod_registration_done == false"| ACT_FLAG_mod_registration["Required: mod_registration"]:::rule
        ACT_DECIDE -->|"p_no_danger_sign == true AND mod_check_vaccines_done == fal…"| ACT_FLAG_mod_check_vaccines["Required: mod_check_vaccines"]:::rule
        ACT_DECIDE -->|"q_has_diarrhoea == true AND mod_diarrhoea_done == false"| ACT_FLAG_mod_diarrhoea["Required: mod_diarrhoea"]:::rule
        ACT_DECIDE -->|"ex_has_fast_breathing == true AND mod_fast_breathing_done =…"| ACT_FLAG_mod_fast_breathing["Required: mod_fast_breathing"]:::rule
        ACT_DECIDE -->|"q_has_fever == true AND mod_fever_malaria_done == false"| ACT_FLAG_mod_fever_malaria["Required: mod_fever_malaria"]:::rule
        ACT_DECIDE -->|"p_no_danger_sign == true AND mod_home_care_advice_done == f…"| ACT_FLAG_mod_home_care_advice["Required: mod_home_care_advice"]:::rule
        ACT_DECIDE -->|"ex_has_muac_yellow_or_red == true AND mod_malnutrition_done…"| ACT_FLAG_mod_malnutrition["Required: mod_malnutrition"]:::rule
        ACT_DECIDE -->|"true"| ACT_FLAG_mod_followup["Required: mod_followup"]:::rule
    end
    START --> ACT_DECIDE

    subgraph RTR["Router (PRIORITY)"]
        ROUTER{{"Priority route"}}:::router
        ROUTER -->|"P0: is_priority_exit == true"| RT_PRIORITY_EXIT["PRIORITY_EXIT"]:::rule
        ROUTER -->|"[!] P0: mod_danger_signs_done == false"| RT_mod_danger_signs["mod_danger_signs"]:::emergency
        ROUTER -->|"P0: mod_prereferral_treatment_done == false"| RT_mod_prereferral_treatment["mod_prereferral_treatment"]:::rule
        ROUTER -->|"P1: mod_registration_done == false"| RT_mod_registration["mod_registration"]:::rule
        ROUTER -->|"[!] P100: p_no_danger_sign == true AND mod_check_vaccines_d…"| RT_mod_check_vaccines["mod_check_vaccines"]:::emergency
        ROUTER -->|"P100: q_has_diarrhoea == true AND mod_diarrhoea_done ==…"| RT_mod_diarrhoea["mod_diarrhoea"]:::rule
        ROUTER -->|"P100: ex_has_fast_breathing == true AND mod_fast_breath…"| RT_mod_fast_breathing["mod_fast_breathing"]:::rule
        ROUTER -->|"P100: q_has_fever == true AND mod_fever_malaria_done ==…"| RT_mod_fever_malaria["mod_fever_malaria"]:::rule
        ROUTER -->|"[!] P100: p_no_danger_sign == true AND mod_home_care_advice…"| RT_mod_home_care_advice["mod_home_care_advice"]:::emergency
        ROUTER -->|"P100: ex_has_muac_yellow_or_red == true AND mod_malnutr…"| RT_mod_malnutrition["mod_malnutrition"]:::rule
        ROUTER -->|"P999: true"| RT_mod_followup["mod_followup"]:::integrative
    end
    ACT_DECIDE --> ROUTER

    subgraph SG_mod_check_vaccines["Check Vaccines (unique)"]
        mod_check_vaccines_ENTRY(["Enter: Check Vaccines"]):::module
        mod_check_vaccines_R0["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == false"| mod_check_vaccines_R0
        mod_check_vaccines_R1["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R1
        mod_check_vaccines_R2["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R2
        mod_check_vaccines_R3["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R3
        mod_check_vaccines_R4["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R4
        mod_check_vaccines_R5["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R5
        mod_check_vaccines_R6["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R6
        mod_check_vaccines_R7["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R7
        mod_check_vaccines_R8["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R8
        mod_check_vaccines_R9["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R9
        mod_check_vaccines_R10["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R10
        mod_check_vaccines_R11["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R11
        mod_check_vaccines_R12["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R12
        mod_check_vaccines_R13["mod_check_vaccines_done: mod_check_vaccines_done; vaccines_up_to_date: vaccines_up_to_date; vaccines_overdue: vaccines_overdue; overdue_vac…"]:::rule
        mod_check_vaccines_ENTRY -->|"p_no_danger_sign == true AND vaccine_card_available == true AND child…"| mod_check_vaccines_R13
    end
    ROUTER -.->|if routed| mod_check_vaccines_ENTRY

    subgraph SG_mod_danger_signs["Assess Danger Signs (unique)"]
        mod_danger_signs_ENTRY(["Enter: Assess Danger Signs"]):::module
        mod_danger_signs_R0["danger_sign_cough: danger_sign_cough"]:::rule
        mod_danger_signs_ENTRY -->|"cough_days &gt;= 14"| mod_danger_signs_R0
        mod_danger_signs_R1["danger_sign_cough: danger_sign_cough"]:::rule
        mod_danger_signs_ENTRY -->|"cough_days &lt; 14"| mod_danger_signs_R1
        mod_danger_signs_R2["danger_sign_cough: danger_sign_diarrhoea"]:::rule
        mod_danger_signs_ENTRY -->|"diarrhoea_days &gt;= 14"| mod_danger_signs_R2
        mod_danger_signs_R3["danger_sign_cough: danger_sign_diarrhoea"]:::rule
        mod_danger_signs_ENTRY -->|"diarrhoea_days &lt; 14 OR diarrhoea_days == null"| mod_danger_signs_R3
        mod_danger_signs_R4["danger_sign_cough: danger_sign_blood_in_stool"]:::rule
        mod_danger_signs_ENTRY -->|"blood_in_stool == true"| mod_danger_signs_R4
        mod_danger_signs_R5["danger_sign_cough: danger_sign_blood_in_stool"]:::rule
        mod_danger_signs_ENTRY -->|"blood_in_stool == false"| mod_danger_signs_R5
        mod_danger_signs_R6["danger_sign_cough: danger_sign_fever"]:::rule
        mod_danger_signs_ENTRY -->|"fever_days &gt;= 7"| mod_danger_signs_R6
        mod_danger_signs_R7["danger_sign_cough: danger_sign_fever"]:::rule
        mod_danger_signs_ENTRY -->|"fever_days &lt; 7 OR fever_days == null"| mod_danger_signs_R7
        mod_danger_signs_R8["danger_sign_cough: danger_sign_convulsions"]:::rule
        mod_danger_signs_ENTRY -->|"convulsions == true"| mod_danger_signs_R8
        mod_danger_signs_R9["danger_sign_cough: danger_sign_convulsions"]:::rule
        mod_danger_signs_ENTRY -->|"convulsions == false"| mod_danger_signs_R9
        mod_danger_signs_R10["danger_sign_cough: danger_sign_unable_to_drink_or_eat"]:::rule
        mod_danger_signs_ENTRY -->|"unable_to_drink_or_eat == true"| mod_danger_signs_R10
        mod_danger_signs_R11["danger_sign_cough: danger_sign_unable_to_drink_or_eat"]:::rule
        mod_danger_signs_ENTRY -->|"unable_to_drink_or_eat == false"| mod_danger_signs_R11
        mod_danger_signs_R12["danger_sign_cough: danger_sign_vomits_everything"]:::rule
        mod_danger_signs_ENTRY -->|"vomits_everything == true"| mod_danger_signs_R12
        mod_danger_signs_R13["danger_sign_cough: danger_sign_vomits_everything"]:::rule
        mod_danger_signs_ENTRY -->|"vomits_everything == false"| mod_danger_signs_R13
        mod_danger_signs_R14["danger_sign_cough: danger_sign_chest_indrawing"]:::rule
        mod_danger_signs_ENTRY -->|"chest_indrawing == true"| mod_danger_signs_R14
        mod_danger_signs_R15["danger_sign_cough: danger_sign_chest_indrawing"]:::rule
        mod_danger_signs_ENTRY -->|"chest_indrawing == false"| mod_danger_signs_R15
        mod_danger_signs_R16["danger_sign_cough: danger_sign_sleepy_unconscious"]:::rule
        mod_danger_signs_ENTRY -->|"unusually_sleepy_or_unconscious == true"| mod_danger_signs_R16
        mod_danger_signs_R17["danger_sign_cough: danger_sign_sleepy_unconscious"]:::rule
        mod_danger_signs_ENTRY -->|"unusually_sleepy_or_unconscious == false"| mod_danger_signs_R17
        mod_danger_signs_R18["danger_sign_cough: danger_sign_severe_malnutrition"]:::rule
        mod_danger_signs_ENTRY -->|"muac_color == 'red'"| mod_danger_signs_R18
        mod_danger_signs_R19["danger_sign_cough: danger_sign_severe_malnutrition"]:::rule
        mod_danger_signs_ENTRY -->|"muac_color != 'red'"| mod_danger_signs_R19
        mod_danger_signs_R20["danger_sign_cough: danger_sign_swelling_both_feet"]:::rule
        mod_danger_signs_ENTRY -->|"swelling_both_feet == true"| mod_danger_signs_R20
        mod_danger_signs_R21["danger_sign_cough: danger_sign_swelling_both_feet"]:::rule
        mod_danger_signs_ENTRY -->|"swelling_both_feet == false"| mod_danger_signs_R21
        mod_danger_signs_R22["danger_sign_cough: fast_breathing"]:::rule
        mod_danger_signs_ENTRY -->|"age_in_months &gt;= 2 AND age_in_months &lt; 12 AND respiratory_rate &gt;= 50"| mod_danger_signs_R22
        mod_danger_signs_R23["danger_sign_cough: fast_breathing"]:::rule
        mod_danger_signs_ENTRY -->|"age_in_months &gt;= 12 AND age_in_months &lt; 60 AND respiratory_rate &gt;= 40"| mod_danger_signs_R23
        mod_danger_signs_R24["danger_sign_cough: fast_breathing"]:::rule
        mod_danger_signs_ENTRY -->|"age_in_months &gt;= 2 AND age_in_months &lt; 12 AND respiratory_rate &lt; 50"| mod_danger_signs_R24
        mod_danger_signs_R25["danger_sign_cough: fast_breathing"]:::rule
        mod_danger_signs_ENTRY -->|"age_in_months &gt;= 12 AND age_in_months &lt; 60 AND respiratory_rate &lt; 40"| mod_danger_signs_R25
        mod_danger_signs_R26["danger_sign_cough: yellow_muac; danger_sign_diarrhoea: counsel_feeding_refer_supplementary"]:::rule
        mod_danger_signs_ENTRY -->|"muac_color == 'yellow'"| mod_danger_signs_R26
        mod_danger_signs_R27["danger_sign_cough: yellow_muac; danger_sign_diarrhoea: counsel_feeding_refer_supplementary"]:::rule
        mod_danger_signs_ENTRY -->|"muac_color != 'yellow'"| mod_danger_signs_R27
        mod_danger_signs_R28["danger_sign_cough: any_danger_sign; danger_sign_diarrhoea: referral_required"]:::rule
        mod_danger_signs_ENTRY -->|"danger_sign_cough == true OR danger_sign_diarrhoea == true OR danger_…"| mod_danger_signs_R28
        mod_danger_signs_R29["danger_sign_cough: any_danger_sign; danger_sign_diarrhoea: referral_required"]:::rule
        mod_danger_signs_ENTRY -->|"danger_sign_cough == false AND danger_sign_diarrhoea == false AND dan…"| mod_danger_signs_R29
        mod_danger_signs_R30["danger_sign_cough: prereferral_ors"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND (diarrhoea_days &gt; 0 OR danger_sign_diarrh…"| mod_danger_signs_R30
        mod_danger_signs_R31["danger_sign_cough: prereferral_ors"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND NOT ((diarrhoea_days &gt; 0 OR danger_sign_d…"| mod_danger_signs_R31
        mod_danger_signs_R32["danger_sign_cough: prereferral_rectal_artesunate; danger_sign_diarrhoea: prereferral_rectal_artesunate_suppositories"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND fever_days &gt; 0 AND (danger_sign_convulsio…"| mod_danger_signs_R32
        mod_danger_signs_R33["danger_sign_cough: prereferral_rectal_artesunate; danger_sign_diarrhoea: prereferral_rectal_artesunate_suppositories"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND fever_days &gt; 0 AND (danger_sign_convulsio…"| mod_danger_signs_R33
        mod_danger_signs_R34["danger_sign_cough: prereferral_rectal_artesunate; danger_sign_diarrhoea: prereferral_rectal_artesunate_suppositories"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND NOT (fever_days &gt; 0 AND (danger_sign_conv…"| mod_danger_signs_R34
        mod_danger_signs_R35["danger_sign_cough: prereferral_al_first_dose; danger_sign_diarrhoea: prereferral_al_tablets"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND fever_days &gt; 0 AND danger_sign_convulsion…"| mod_danger_signs_R35
        mod_danger_signs_R36["danger_sign_cough: prereferral_al_first_dose; danger_sign_diarrhoea: prereferral_al_tablets"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND fever_days &gt; 0 AND danger_sign_convulsion…"| mod_danger_signs_R36
        mod_danger_signs_R37["danger_sign_cough: prereferral_al_first_dose; danger_sign_diarrhoea: prereferral_al_tablets"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND NOT (fever_days &gt; 0 AND danger_sign_convu…"| mod_danger_signs_R37
        mod_danger_signs_R38["danger_sign_cough: prereferral_amoxicillin_first_dose; danger_sign_diarrhoea: prereferral_amoxicillin_tablets"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND (danger_sign_chest_indrawing == true OR f…"| mod_danger_signs_R38
        mod_danger_signs_R39["danger_sign_cough: prereferral_amoxicillin_first_dose; danger_sign_diarrhoea: prereferral_amoxicillin_tablets"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND (danger_sign_chest_indrawing == true OR f…"| mod_danger_signs_R39
        mod_danger_signs_R40["danger_sign_cough: prereferral_amoxicillin_first_dose; danger_sign_diarrhoea: prereferral_amoxicillin_tablets"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true AND NOT ((danger_sign_chest_indrawing == true…"| mod_danger_signs_R40
        mod_danger_signs_R41["danger_sign_cough: treat_diarrhoea_ors_zinc"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND diarrhoea_days &gt; 0 AND diarrhoea_days &lt; …"| mod_danger_signs_R41
        mod_danger_signs_R42["danger_sign_cough: treat_diarrhoea_ors_zinc"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND NOT (diarrhoea_days &gt; 0 AND diarrhoea_da…"| mod_danger_signs_R42
        mod_danger_signs_R43["danger_sign_cough: zinc_half_tab_days; danger_sign_diarrhoea: zinc_full_tab_days"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND diarrhoea_days &gt; 0 AND diarrhoea_days &lt; …"| mod_danger_signs_R43
        mod_danger_signs_R44["danger_sign_cough: zinc_half_tab_days; danger_sign_diarrhoea: zinc_full_tab_days"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND diarrhoea_days &gt; 0 AND diarrhoea_days &lt; …"| mod_danger_signs_R44
        mod_danger_signs_R45["danger_sign_cough: treat_fever_rdt"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND fever_days &gt; 0 AND fever_days &lt; 7 AND ma…"| mod_danger_signs_R45
        mod_danger_signs_R46["danger_sign_cough: treat_fever_rdt"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND NOT (fever_days &gt; 0 AND fever_days &lt; 7 A…"| mod_danger_signs_R46
        mod_danger_signs_R47["danger_sign_cough: treat_fever_al; danger_sign_diarrhoea: al_tabs_per_dose; danger_sign_blood_in_stool: al_total_tabs"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND fever_days &gt; 0 AND fever_days &lt; 7 AND ma…"| mod_danger_signs_R47
        mod_danger_signs_R48["danger_sign_cough: treat_fever_al; danger_sign_diarrhoea: al_tabs_per_dose; danger_sign_blood_in_stool: al_total_tabs"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND fever_days &gt; 0 AND fever_days &lt; 7 AND ma…"| mod_danger_signs_R48
        mod_danger_signs_R49["danger_sign_cough: treat_fever_al; danger_sign_diarrhoea: al_tabs_per_dose; danger_sign_blood_in_stool: al_total_tabs"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND NOT (fever_days &gt; 0 AND fever_days &lt; 7 A…"| mod_danger_signs_R49
        mod_danger_signs_R50["danger_sign_cough: treat_fast_breathing_amoxicillin; danger_sign_diarrhoea: amoxicillin_tabs_per_dose; danger_sign_blood_in_stool: amoxicil…"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND fast_breathing == true AND chest_indrawi…"| mod_danger_signs_R50
        mod_danger_signs_R51["danger_sign_cough: treat_fast_breathing_amoxicillin; danger_sign_diarrhoea: amoxicillin_tabs_per_dose; danger_sign_blood_in_stool: amoxicil…"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND fast_breathing == true AND chest_indrawi…"| mod_danger_signs_R51
        mod_danger_signs_R52["danger_sign_cough: treat_fast_breathing_amoxicillin; danger_sign_diarrhoea: amoxicillin_tabs_per_dose; danger_sign_blood_in_stool: amoxicil…"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false AND NOT (fast_breathing == true AND chest_in…"| mod_danger_signs_R52
        mod_danger_signs_R53["danger_sign_cough: advise_fluids_feeding_return_bednet; danger_sign_diarrhoea: followup_days; danger_sign_blood_in_stool: mod_danger_signs_…"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == false"| mod_danger_signs_R53
        mod_danger_signs_R54["danger_sign_cough: advise_fluids_feeding_return_bednet; danger_sign_diarrhoea: followup_days; danger_sign_blood_in_stool: mod_danger_signs_…"]:::rule
        mod_danger_signs_ENTRY -->|"any_danger_sign == true"| mod_danger_signs_R54
    end
    ROUTER -.->|if routed| mod_danger_signs_ENTRY

    subgraph SG_mod_diarrhoea["Treat Diarrhoea (ORS + Zinc) (unique)"]
        mod_diarrhoea_ENTRY(["Enter: Treat Diarrhoea (ORS + Zinc)"]):::module
        mod_diarrhoea_R0["out_diarrhoea_classification: out_diarrhoea_classification; out_diarrhoea_action: out_danger_sign_reason; out_ors_instruction: out_refer_ur…"]:::emergency
        mod_diarrhoea_ENTRY -->|"q_has_diarrhoea == true AND q_blood_in_stool == true"| mod_diarrhoea_R0
        mod_diarrhoea_R1["out_diarrhoea_classification: out_diarrhoea_classification; out_diarrhoea_action: out_danger_sign_reason; out_ors_instruction: out_refer_ur…"]:::emergency
        mod_diarrhoea_ENTRY -->|"q_has_diarrhoea == true AND q_diarrhoea_days &gt;= 14 AND q_blood_in_sto…"| mod_diarrhoea_R1
        mod_diarrhoea_R2["out_diarrhoea_classification: out_diarrhoea_classification; out_diarrhoea_action: out_danger_sign_reason; out_ors_instruction: out_refer_ur…"]:::emergency
        mod_diarrhoea_ENTRY -->|"q_has_diarrhoea == true AND q_diarrhoea_days &lt; 14 AND q_blood_in_stoo…"| mod_diarrhoea_R2
        mod_diarrhoea_R3["out_diarrhoea_classification: out_diarrhoea_classification; out_diarrhoea_action: out_danger_sign_reason; out_ors_instruction: out_refer_ur…"]:::emergency
        mod_diarrhoea_ENTRY -->|"q_has_diarrhoea == true AND q_diarrhoea_days &lt; 14 AND q_blood_in_stoo…"| mod_diarrhoea_R3
        mod_diarrhoea_R4["out_diarrhoea_classification: out_diarrhoea_classification; out_diarrhoea_action: out_diarrhoea_action; out_ors_instruction: out_refer_urge…"]:::rule
        mod_diarrhoea_ENTRY -->|"q_has_diarrhoea == true AND q_diarrhoea_days &lt; 14 AND q_blood_in_stoo…"| mod_diarrhoea_R4
        mod_diarrhoea_R5["out_diarrhoea_classification: out_diarrhoea_classification; out_diarrhoea_action: out_diarrhoea_action; out_ors_instruction: out_refer_urge…"]:::rule
        mod_diarrhoea_ENTRY -->|"q_has_diarrhoea == true AND q_diarrhoea_days &lt; 14 AND q_blood_in_stoo…"| mod_diarrhoea_R5
    end
    ROUTER -.->|if routed| mod_diarrhoea_ENTRY

    subgraph SG_mod_fast_breathing["Treat Fast Breathing / Pneumonia (Amoxicillin) (unique)"]
        mod_fast_breathing_ENTRY(["Enter: Treat Fast Breathing / Pneumonia (Amoxi…"]):::module
        mod_fast_breathing_R0["mod_fast_breathing_done: tx_amoxicillin_indication; tx_amoxicillin_dose_tabs: tx_amoxicillin_prereferral; tx_amoxicillin_frequency: tx_amox…"]:::emergency
        mod_fast_breathing_ENTRY -->|"ex_has_fast_breathing == true AND ex_has_chest_indrawing == true AND …"| mod_fast_breathing_R0
        mod_fast_breathing_R1["mod_fast_breathing_done: tx_amoxicillin_indication; tx_amoxicillin_dose_tabs: tx_amoxicillin_prereferral; tx_amoxicillin_frequency: tx_amox…"]:::emergency
        mod_fast_breathing_ENTRY -->|"ex_has_fast_breathing == true AND ex_has_chest_indrawing == false AND…"| mod_fast_breathing_R1
        mod_fast_breathing_R2["mod_fast_breathing_done: tx_amoxicillin_indication; tx_amoxicillin_dose_tabs: tx_amoxicillin_prereferral; tx_amoxicillin_frequency: tx_amox…"]:::emergency
        mod_fast_breathing_ENTRY -->|"ex_has_fast_breathing == true AND ex_has_danger_sign == true AND ex_c…"| mod_fast_breathing_R2
        mod_fast_breathing_R3["mod_fast_breathing_done: tx_amoxicillin_indication; tx_amoxicillin_dose_tabs: tx_amoxicillin_prereferral; tx_amoxicillin_frequency: tx_amox…"]:::rule
        mod_fast_breathing_ENTRY -->|"ex_has_fast_breathing == true AND ex_has_danger_sign == false AND chi…"| mod_fast_breathing_R3
        mod_fast_breathing_R4["mod_fast_breathing_done: tx_amoxicillin_indication; tx_amoxicillin_dose_tabs: tx_amoxicillin_prereferral; tx_amoxicillin_frequency: tx_amox…"]:::rule
        mod_fast_breathing_ENTRY -->|"ex_has_fast_breathing == true AND ex_has_danger_sign == false AND chi…"| mod_fast_breathing_R4
    end
    ROUTER -.->|if routed| mod_fast_breathing_ENTRY

    subgraph SG_mod_fever_malaria["Treat Fever / Malaria (RDT + AL) (unique)"]
        mod_fever_malaria_ENTRY(["Enter: Treat Fever / Malaria (RDT + AL)"]):::module
        mod_fever_malaria_R0["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_rectal_artesunate; out_pre_referral_rect…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &gt;= 7 AND (q_convulsions == true …"| mod_fever_malaria_R0
        mod_fever_malaria_R1["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_rectal_artesunate; out_pre_referral_rect…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &gt;= 7 AND (q_convulsions == true …"| mod_fever_malaria_R1
        mod_fever_malaria_R2["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_rectal_artesunate; out_pre_referral_rect…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &lt; 7 AND (q_convulsions == true O…"| mod_fever_malaria_R2
        mod_fever_malaria_R3["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_rectal_artesunate; out_pre_referral_rect…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &lt; 7 AND (q_convulsions == true O…"| mod_fever_malaria_R3
        mod_fever_malaria_R4["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_al_first_dose; out_pre_referral_rectal_a…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &gt;= 7 AND q_convulsions == false …"| mod_fever_malaria_R4
        mod_fever_malaria_R5["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_al_first_dose; out_pre_referral_rectal_a…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &gt;= 7 AND q_convulsions == false …"| mod_fever_malaria_R5
        mod_fever_malaria_R6["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_pre_referral_al_first_dose; out_pre_referral_rectal_a…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &gt;= 7 AND q_convulsions == false …"| mod_fever_malaria_R6
        mod_fever_malaria_R7["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_al_treatment; out_pre_referral_rectal_artesunate_dose…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &lt; 7 AND q_convulsions == false A…"| mod_fever_malaria_R7
        mod_fever_malaria_R8["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_al_treatment; out_pre_referral_rectal_artesunate_dose…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &lt; 7 AND q_convulsions == false A…"| mod_fever_malaria_R8
        mod_fever_malaria_R9["out_danger_sign_fever: out_danger_sign_fever; out_pre_referral_rectal_artesunate: out_al_treatment; out_pre_referral_rectal_artesunate_dose…"]:::rule
        mod_fever_malaria_ENTRY -->|"q_has_fever == true AND q_fever_days &lt; 7 AND q_convulsions == false A…"| mod_fever_malaria_R9
    end
    ROUTER -.->|if routed| mod_fever_malaria_ENTRY

    subgraph SG_mod_followup["Follow-up & Closing (unique)"]
        mod_followup_ENTRY(["Enter: Follow-up & Closing"]):::module
        mod_followup_R0["mod_followup_done: followup_new_danger_sign; followup_action: followup_referral_urgent; followup_treat_at_home: followup_counsel_message; f…"]:::emergency
        mod_followup_ENTRY -->|"visit_type == 'followup' AND (cough_days &gt;= 14 OR diarrhoea_days &gt;= 1…"| mod_followup_R0
        mod_followup_R1["mod_followup_done: followup_preref_ors; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent == true AND dia…"| mod_followup_R1
        mod_followup_R2["mod_followup_done: followup_preref_rectal_artesunate; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent == true AND fev…"| mod_followup_R2
        mod_followup_R3["mod_followup_done: followup_preref_al; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent == true AND fev…"| mod_followup_R3
        mod_followup_R4["mod_followup_done: followup_preref_amoxicillin; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent == true AND (ch…"| mod_followup_R4
        mod_followup_R5["mod_followup_done: followup_condition_improving; followup_action: followup_complete_treatment; followup_treat_at_home: followup_counsel_mes…"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent != true AND con…"| mod_followup_R5
        mod_followup_R6["mod_followup_done: followup_condition_not_improving; followup_action: followup_reassess_needed; followup_treat_at_home: followup_counsel_me…"]:::emergency
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent != true AND con…"| mod_followup_R6
        mod_followup_R7["mod_followup_done: followup_reassess_needed; followup_action: followup_action; followup_treat_at_home: mod_followup_done"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND new_problem_present == true"| mod_followup_R7
        mod_followup_R8["mod_followup_done: followup_action; followup_action: followup_treat_at_home; followup_treat_at_home: followup_schedule_next_visit"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_day == 3 AND diarrhoea_present …"| mod_followup_R8
        mod_followup_R9["mod_followup_done: followup_action; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND diarrhoea_present == true AND zinc_days_…"| mod_followup_R9
        mod_followup_R10["mod_followup_done: followup_action; followup_action: followup_referral_urgent; followup_treat_at_home: mod_followup_done"]:::emergency
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_day == 3 AND fever_present == t…"| mod_followup_R10
        mod_followup_R11["mod_followup_done: followup_action; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_day == 3 AND fever_present == f…"| mod_followup_R11
        mod_followup_R12["mod_followup_done: followup_action; followup_action: followup_complete_treatment"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND fever_present == true AND rdt_result == …"| mod_followup_R12
        mod_followup_R13["mod_followup_done: followup_action; followup_action: followup_complete_treatment"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND fast_breathing_present == false AND amox…"| mod_followup_R13
        mod_followup_R14["mod_followup_done: followup_action; followup_action: followup_reassess_needed; followup_treat_at_home: mod_followup_done"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_day == 3 AND fast_breathing_pre…"| mod_followup_R14
        mod_followup_R15["mod_followup_done: followup_action; followup_action: followup_referral_urgent; followup_treat_at_home: mod_followup_done"]:::emergency
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_reassess_needed == true AND fas…"| mod_followup_R15
        mod_followup_R16["mod_followup_done: followup_action; followup_action: followup_counsel_message"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND muac_color == 'yellow' AND followup_refe…"| mod_followup_R16
        mod_followup_R17["mod_followup_done: followup_action; followup_action: followup_close_case; followup_treat_at_home: mod_followup_done"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND condition_improving == true AND new_prob…"| mod_followup_R17
        mod_followup_R18["mod_followup_done: followup_counsel_message; followup_action: followup_schedule_next_visit"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'followup' AND followup_referral_urgent != true"| mod_followup_R18
        mod_followup_R19["mod_followup_done: followup_action; followup_action: followup_schedule_next_visit; followup_treat_at_home: mod_followup_done"]:::rule
        mod_followup_ENTRY -->|"visit_type == 'initial' AND followup_referral_urgent != true AND (tre…"| mod_followup_R19
    end
    ROUTER -.->|if routed| mod_followup_ENTRY

    subgraph SG_mod_home_care_advice["Advise on Home Care (unique)"]
        mod_home_care_advice_ENTRY(["Enter: Advise on Home Care"]):::module
        mod_home_care_advice_R0["tx_ors: tx_ors; tx_ors_packets_home: tx_ors_packets_home; tx_ors_instruction: tx_ors_instruction; tx_zinc: tx_zinc; tx_zinc_dose_tabs: tx_z…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_diarrhoea == true AND p_diarrhoea_days…"| mod_home_care_advice_R0
        mod_home_care_advice_R1["tx_ors: tx_ors; tx_ors_packets_home: tx_ors_packets_home; tx_ors_instruction: tx_ors_instruction; tx_zinc: tx_zinc; tx_zinc_dose_tabs: tx_z…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_diarrhoea == true AND p_diarrhoea_days…"| mod_home_care_advice_R1
        mod_home_care_advice_R2["tx_ors: tx_rdt_indicated; tx_ors_packets_home: adv_increase_fluids_feeding; tx_ors_instruction: adv_when_to_return; tx_zinc: adv_bednet; tx…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_fever == true AND p_fever_days &lt; 7 AND…"| mod_home_care_advice_R2
        mod_home_care_advice_R3["tx_ors: tx_al; tx_ors_packets_home: tx_al_dose_tabs; tx_ors_instruction: tx_al_total_tabs; tx_zinc: tx_al_second_dose_hours; tx_zinc_dose_t…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_fever == true AND p_fever_days &lt; 7 AND…"| mod_home_care_advice_R3
        mod_home_care_advice_R4["tx_ors: tx_al; tx_ors_packets_home: tx_al_dose_tabs; tx_ors_instruction: tx_al_total_tabs; tx_zinc: tx_al_second_dose_hours; tx_zinc_dose_t…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_fever == true AND p_fever_days &lt; 7 AND…"| mod_home_care_advice_R4
        mod_home_care_advice_R5["tx_ors: tx_al; tx_ors_packets_home: adv_increase_fluids_feeding; tx_ors_instruction: adv_when_to_return; tx_zinc: adv_bednet; tx_zinc_dose_…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_fever == true AND p_fever_days &lt; 7 AND…"| mod_home_care_advice_R5
        mod_home_care_advice_R6["tx_ors: tx_amoxicillin; tx_ors_packets_home: tx_amoxicillin_dose_tabs; tx_ors_instruction: tx_amoxicillin_total_tabs; tx_zinc: tx_amoxicill…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_fast_breathing == true AND p_chest_ind…"| mod_home_care_advice_R6
        mod_home_care_advice_R7["tx_ors: tx_amoxicillin; tx_ors_packets_home: tx_amoxicillin_dose_tabs; tx_ors_instruction: tx_amoxicillin_total_tabs; tx_zinc: tx_amoxicill…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_fast_breathing == true AND p_chest_ind…"| mod_home_care_advice_R7
        mod_home_care_advice_R8["tx_ors: tx_muac_yellow_counsel; tx_ors_packets_home: tx_muac_yellow_refer_supplementary; tx_ors_instruction: adv_increase_fluids_feeding; t…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_muac_colour == 'yellow'"| mod_home_care_advice_R8
        mod_home_care_advice_R9["tx_ors: adv_increase_fluids_feeding; tx_ors_packets_home: adv_when_to_return; tx_ors_instruction: adv_bednet; tx_zinc: adv_followup_days; t…"]:::rule
        mod_home_care_advice_ENTRY -->|"p_no_danger_sign == true AND p_diarrhoea == false AND p_fever == fals…"| mod_home_care_advice_R9
    end
    ROUTER -.->|if routed| mod_home_care_advice_ENTRY

    subgraph SG_mod_malnutrition["Assess & Manage Malnutrition (MUAC) (unique)"]
        mod_malnutrition_ENTRY(["Enter: Assess & Manage Malnutrition (MUAC)"]):::module
        mod_malnutrition_R0["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'red'"| mod_malnutrition_R0
        mod_malnutrition_R1["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND has_swelling_both_feet == true"| mod_malnutrition_R1
        mod_malnutrition_R2["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND has_chest_indrawing == true"| mod_malnutrition_R2
        mod_malnutrition_R3["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND has_convulsions == true"| mod_malnutrition_R3
        mod_malnutrition_R4["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND is_unable_to_drink_or_eat == true"| mod_malnutrition_R4
        mod_malnutrition_R5["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND vomits_everything == true"| mod_malnutrition_R5
        mod_malnutrition_R6["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND is_unusually_sleepy_or_unconscious == true"| mod_malnutrition_R6
        mod_malnutrition_R7["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND cough_days &gt;= 14"| mod_malnutrition_R7
        mod_malnutrition_R8["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND diarrhoea_days &gt;= 14"| mod_malnutrition_R8
        mod_malnutrition_R9["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND has_blood_in_stool == true"| mod_malnutrition_R9
        mod_malnutrition_R10["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: danger_sign_reason;…"]:::emergency
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND fever_days &gt;= 7"| mod_malnutrition_R10
        mod_malnutrition_R11["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: action_give_ors; ac…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_diarr…"| mod_malnutrition_R11
        mod_malnutrition_R12["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: action_give_ors; ac…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_diarr…"| mod_malnutrition_R12
        mod_malnutrition_R13["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: action_do_rdt; acti…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_fever…"| mod_malnutrition_R13
        mod_malnutrition_R14["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: action_do_rdt; acti…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_fever…"| mod_malnutrition_R14
        mod_malnutrition_R15["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: action_do_rdt; acti…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_fever…"| mod_malnutrition_R15
        mod_malnutrition_R16["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: has_fast_breathing;…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_chest…"| mod_malnutrition_R16
        mod_malnutrition_R17["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: has_fast_breathing;…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_chest…"| mod_malnutrition_R17
        mod_malnutrition_R18["classification_malnutrition: classification_malnutrition; danger_sign_present: danger_sign_present; danger_sign_reason: action_counsel_feed…"]:::rule
        mod_malnutrition_ENTRY -->|"muac_color == 'yellow' AND danger_sign_present == false AND has_diarr…"| mod_malnutrition_R18
    end
    ROUTER -.->|if routed| mod_malnutrition_ENTRY

    subgraph SG_mod_prereferral_treatment["Pre-Referral Treatment (unique)"]
        mod_prereferral_treatment_ENTRY(["Enter: Pre-Referral Treatment"]):::module
        mod_prereferral_treatment_R0["prereferral_ors: prereferral_ors; prereferral_rectal_artesunate: prereferral_instructions"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND p_has_diarrhoea == true AND p_can_drink…"| mod_prereferral_treatment_R0
        mod_prereferral_treatment_R1["prereferral_ors: prereferral_rectal_artesunate; prereferral_rectal_artesunate: prereferral_rectal_artesunate_dose_suppositories; prereferra…"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND p_has_fever == true AND (p_has_convulsi…"| mod_prereferral_treatment_R1
        mod_prereferral_treatment_R2["prereferral_ors: prereferral_rectal_artesunate; prereferral_rectal_artesunate: prereferral_rectal_artesunate_dose_suppositories; prereferra…"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND p_has_fever == true AND (p_has_convulsi…"| mod_prereferral_treatment_R2
        mod_prereferral_treatment_R3["prereferral_ors: prereferral_al_first_dose; prereferral_rectal_artesunate: prereferral_al_first_dose_tabs; prereferral_rectal_artesunate_do…"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND p_has_fever == true AND p_has_convulsio…"| mod_prereferral_treatment_R3
        mod_prereferral_treatment_R4["prereferral_ors: prereferral_al_first_dose; prereferral_rectal_artesunate: prereferral_al_first_dose_tabs; prereferral_rectal_artesunate_do…"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND p_has_fever == true AND p_has_convulsio…"| mod_prereferral_treatment_R4
        mod_prereferral_treatment_R5["prereferral_ors: prereferral_amoxicillin_first_dose; prereferral_rectal_artesunate: prereferral_amoxicillin_first_dose_tabs; prereferral_re…"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND (p_has_chest_indrawing == true OR p_has…"| mod_prereferral_treatment_R5
        mod_prereferral_treatment_R6["prereferral_ors: prereferral_amoxicillin_first_dose; prereferral_rectal_artesunate: prereferral_amoxicillin_first_dose_tabs; prereferral_re…"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND (p_has_chest_indrawing == true OR p_has…"| mod_prereferral_treatment_R6
        mod_prereferral_treatment_R7["prereferral_ors: mod_prereferral_treatment_done"]:::rule
        mod_prereferral_treatment_ENTRY -->|"p_has_danger_sign == true AND mod_prereferral_treatment_done != true"| mod_prereferral_treatment_R7
    end
    ROUTER -.->|if routed| mod_prereferral_treatment_ENTRY

    subgraph SG_mod_registration["Registration & Demographics (unique)"]
        mod_registration_ENTRY(["Enter: Registration & Demographics"]):::module
        mod_registration_R0["mod_registration_done: age_eligible; age_band: ineligible_reason; age_eligible: mod_registration_done"]:::rule
        mod_registration_ENTRY -->|"age_in_months &lt; 2"| mod_registration_R0
        mod_registration_R1["mod_registration_done: age_eligible; age_band: ineligible_reason; age_eligible: mod_registration_done"]:::rule
        mod_registration_ENTRY -->|"age_in_months &gt;= 60"| mod_registration_R1
        mod_registration_R2["mod_registration_done: age_eligible; age_band: age_band; age_eligible: fast_breathing_threshold_bpm; ineligible_reason: zinc_dose_tabs; fas…"]:::rule
        mod_registration_ENTRY -->|"age_in_months &gt;= 2 AND age_in_months &lt; 6"| mod_registration_R2
        mod_registration_R3["mod_registration_done: age_eligible; age_band: age_band; age_eligible: fast_breathing_threshold_bpm; ineligible_reason: zinc_dose_tabs; fas…"]:::rule
        mod_registration_ENTRY -->|"age_in_months &gt;= 6 AND age_in_months &lt; 12"| mod_registration_R3
        mod_registration_R4["mod_registration_done: age_eligible; age_band: age_band; age_eligible: fast_breathing_threshold_bpm; ineligible_reason: zinc_dose_tabs; fas…"]:::rule
        mod_registration_ENTRY -->|"age_in_months &gt;= 12 AND age_in_months &lt; 36"| mod_registration_R4
        mod_registration_R5["mod_registration_done: age_eligible; age_band: age_band; age_eligible: fast_breathing_threshold_bpm; ineligible_reason: zinc_dose_tabs; fas…"]:::rule
        mod_registration_ENTRY -->|"age_in_months &gt;= 36 AND age_in_months &lt; 60"| mod_registration_R5
    end
    ROUTER -.->|if routed| mod_registration_ENTRY

    subgraph INT["Integrative (merge outputs)"]
        INT_MERGE["Merge per-module outputs\n• highest referral wins\n• treatments additive (unless contraindicated)\n• shortest follow-up"]:::integrative
    end

    DONE(["Care plan complete"]):::done
    mod_check_vaccines_R13 --> INT_MERGE
    mod_danger_signs_R54 --> INT_MERGE
    mod_diarrhoea_R5 --> INT_MERGE
    mod_fast_breathing_R4 --> INT_MERGE
    mod_fever_malaria_R9 --> INT_MERGE
    mod_followup_R19 --> INT_MERGE
    mod_home_care_advice_R9 --> INT_MERGE
    mod_malnutrition_R18 --> INT_MERGE
    mod_prereferral_treatment_R7 --> INT_MERGE
    mod_registration_R5 --> INT_MERGE
    INT_MERGE --> DONE